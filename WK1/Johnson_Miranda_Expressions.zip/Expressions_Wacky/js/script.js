//Miranda Johnson
//WPF - Expressions Wacky
//May 15, 2014


//Socks lost at the laundry mat

var socks = 100; //declare socks variable

var socksR = socks - 2; //Socks missing variable
  
console.log(socksR); //Print out Socks Remaining

socksMo = socks - socksR; //Socks missing per month

console.log(socksMo); //Print out socks missing per month

socksMom = socksR * 4; //Total socks lost per month

console.log(socksMom); //Print out socks missing per month

